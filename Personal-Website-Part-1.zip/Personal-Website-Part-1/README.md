# Personal-Website-Part-1
Building a Personal Website part 1.

Deployment link: https://eddie1116.github.io/Personal-Website-Part-1/

Working on each steps one day at a time used example on block 9 to create my P.W.S